package org.shortpasta.novnc.ws;

import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Map;
import java.util.HashMap;

import org.shortpasta.novnc.util.AsyncCallback;
import org.shortpasta.novnc.util.Logger;
import org.shortpasta.novnc.util.Base64Util;
import org.shortpasta.novnc.net.TcpEndpoint;

import org.java_websocket.WebSocket;
import org.java_websocket.WebSocketServer;
import org.java_websocket.handshake.ClientHandshake;

/**
 * ShortPasta Foundation
 * http://www.shortpasta.org
 * Copyright 2009 and beyond, Sal Ingrilli at the ShortPasta Software Foundation
 * <p/>
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License version 3
 * as published by the Free Software Foundation as long as:
 * 1. You credit the original author somewhere within your product or website
 * 2. The credit is easily reachable and not burried deep
 * 3. Your end-user can easily see it
 * 4. You register your name (optional) and company/group/org name (required)
 * at http://www.shortpasta.org
 * 5. You do all of the above within 4 weeks of integrating this software
 * 6. You contribute feedback, fixes, and requests for features
 * <p/>
 * If/when you derive a commercial gain from using this software
 * please donate at http://www.shortpasta.org
 * <p/>
 * If prefer or require, contact the author specified above to:
 * 1. Release you from the above requirements
 * 2. Acquire a commercial license
 * 3. Purchase a support contract
 * 4. Request a different license
 * 5. Anything else
 * <p/>
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE, similarly
 * to how this is described in the GNU Lesser General Public License.
 * <p/>
 * User: Sal Ingrilli
 * Date: May 10, 2012
 * Time: 5:52:37 PM
 */
public class NovncServer {
  
  // my attributes
  private final Logger logger = new Logger (getClass ());
  private int port;
  private String destinationHost;
  private int destinationPort;
  private WebSocketServer webSocketServer;
  private final Map<WebSocket, TcpEndpoint> webSocketToTcpEndpointMap = new HashMap<WebSocket, TcpEndpoint> ();
  
  // my attributes
  public void setPort (final int port) { this.port = port; }
  public int getPort () { return port; }
  
  public void setDestinationHost (final String destinationHost) { this.destinationHost = destinationHost; }
  public String getDestinationHost () { return destinationHost; }
  
  public void setDestinationPort (final int destinationPort) { this.destinationPort = destinationPort; }
  public int getDestinationPort () { return destinationPort; }

  /**
   * The Java entry point
   * @param args
   */
  public static void main (final String[] args)
    throws Exception {
    
    final NovncServer novncServer = new NovncServer ();
    novncServer.setPort (10000);
    novncServer.setDestinationHost ("192.168.0.181");
    novncServer.setDestinationPort (5900);
    novncServer.start ();
    Thread.sleep (120 * 1000);
  }

  /**
   * Starts the server on the given port
   */
  public void start () {
    
    // helpers
    logger.debug ("start ()");
    
    // create a WebSocketServer
    final InetSocketAddress inetSocketAddress = new InetSocketAddress ("localhost", port);
    final org.java_websocket.drafts.Draft draft = new org.java_websocket.drafts.Draft_17 ();
    webSocketServer = new WebSocketServer (inetSocketAddress, draft) {
      
      @Override
      public void onOpen (final WebSocket webSocket, final ClientHandshake handshake) {
        logger.debug ("onOpen (). webSocket: " + webSocket + ", resourceDescriptor: " + handshake.getResourceDescriptor ());
        NovncServer.this.startWebSocket (webSocket);
      }
      
      @Override
      public void onClose (final WebSocket webSocket, final int code, final String reason, final boolean remote) {
        logger.debug ("onClose (). webSocket: " + webSocket);
        stopWebSocket (webSocket);
      }
      
      @Override
      public void onError (final WebSocket webSocket, final Exception e) {
        logger.debug ("onError (). webSocket: " + webSocket);
        logger.error (e);
      }
    
      @Override
      public void onMessage (final WebSocket webSocket, final String message) {
        logger.debug ("onMessage (). message: " + message);
      }
      
      @Override
      public void onMessage (final WebSocket webSocket, final byte[] bytes) {
        logger.debug ("onMessage (). bytes: " + bytes.length);
        final TcpEndpoint tcpEndpoint = webSocketToTcpEndpointMap.get (webSocket);
        if (tcpEndpoint != null) {
          final String encodedData = new String (bytes);
          final byte[] decodedData = Base64Util.decode (encodedData);
          tcpEndpoint.writeAsync (decodedData);
        }
      }
    
      /*@Override
      public void onMessage (final WebSocket conn, final ByteBuffer blob) {
        final byte[] data = blob.array ();
        debug ("onMessage (). blob: " + data.length + " bytes");
      }*/
    };
    
    // start the server
    logger.debug ("starting webSocketServer on port " + webSocketServer.getPort ());
    webSocketServer.start ();
  }

  /**
   * Stops this Server
   */
  public void stop () {
    
    // helpers
    logger.debug ("stop ()");
    
    // handle exceptions
    try {

      // delegate
      webSocketServer.stop ();
      webSocketServer = null;
    }
    catch (final Exception e) {
      
      e.printStackTrace ();
    }
  }

  /**
   * Handles a new WebSocketServer client
   * @param webSocket
   */
  private void startWebSocket (final WebSocket webSocket) {
    
    // helpers
    logger.debug ("startWebSocket ()");

    // if an existing client is running, kill it
    stopWebSocket (webSocket);
    
    // open a connection to the target
    final TcpEndpoint destinationTcpEndpoint;
    try {

      final int connectTimeout = 0; // 10 * 1000;
      logger.debug ("connecting to " + destinationHost + ":" + destinationPort + " with connectTimeout: " + connectTimeout);
      final InetSocketAddress inetSocketAddress = new InetSocketAddress (destinationHost, destinationPort);
      final Socket destinationSocket = new Socket ();
      destinationSocket.connect (inetSocketAddress, connectTimeout);
      
      // initialize endpoint
      logger.debug ("initializing endpoint");
      destinationTcpEndpoint = new TcpEndpoint ();
      destinationTcpEndpoint.setInputStream (destinationSocket.getInputStream ());
      destinationTcpEndpoint.setOutputStream (destinationSocket.getOutputStream ());
      
      destinationTcpEndpoint.setOnReadAsyncCallback (new AsyncCallback<byte[]> () {
        public void onSuccess (final byte[] byteArray) {
          try {
            final String encodedData = Base64Util.encode (byteArray);
            final byte[] encodedDataAsByteArray = encodedData.getBytes ();
            logger.debug ("onOpen ().TcpEndpoint.onSuccess (): sending " + byteArray.length + " raw / " + encodedDataAsByteArray.length + " encoded bytes to client");
            webSocket.send (encodedDataAsByteArray);
          }
          catch (final InterruptedException e) {
            logger.warn ("onOpen ().TcpEndpoint.onSuccess (): caught interrupted signal: propagating");
            Thread.currentThread ().interrupt ();
          }
        }
      });
      
      // track so this is immediately available for WebSocketServer.onMessage ()
      webSocketToTcpEndpointMap.put (webSocket, destinationTcpEndpoint);
      
      // start
      logger.debug ("starting endpoint");
      destinationTcpEndpoint.start ();
    }
    catch (final Exception e) {
      
      // log
      logger.error (e);
      
      // cleanup
      stopWebSocket (webSocket);
    }
    finally {
      
      // log
      logger.debug ("startWebSocket (): done");
    }
  }

  /**
   * Uniformely stops any existing VncClient
   * @param webSocket
   */
  private void stopWebSocket (final WebSocket webSocket) {
    
    // helpers
    logger.debug ("stopWebSocket ()");
    
    // remove
    final TcpEndpoint destinationTcpEndpoint = webSocketToTcpEndpointMap.remove (webSocket);
    
    // cleanup
    if (destinationTcpEndpoint != null) {
      
      logger.debug ("stopping destinationTcpEndpoint");
      destinationTcpEndpoint.stop ();
    }
  }
}