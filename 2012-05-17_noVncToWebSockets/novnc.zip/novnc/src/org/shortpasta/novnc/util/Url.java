package org.shortpasta.novnc.util;

import java.util.List;
import java.util.LinkedList;
import java.util.Map;
import java.util.HashMap;

import org.shortpasta.novnc.util.StringUtil;

/**
 * ShortPasta Foundation
 * http://www.shortpasta.org
 * Copyright 2009 and beyond, Sal Ingrilli at the ShortPasta Software Foundation
 * <p/>
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License version 3
 * as published by the Free Software Foundation as long as:
 * 1. You credit the original author somewhere within your product or website
 * 2. The credit is easily reachable and not burried deep
 * 3. Your end-user can easily see it
 * 4. You register your name (optional) and company/group/org name (required)
 * at http://www.shortpasta.org
 * 5. You do all of the above within 4 weeks of integrating this software
 * 6. You contribute feedback, fixes, and requests for features
 * <p/>
 * If/when you derive a commercial gain from using this software
 * please donate at http://www.shortpasta.org
 * <p/>
 * If prefer or require, contact the author specified above to:
 * 1. Release you from the above requirements
 * 2. Acquire a commercial license
 * 3. Purchase a support contract
 * 4. Request a different license
 * 5. Anything else
 * <p/>
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE, similarly
 * to how this is described in the GNU Lesser General Public License.
 * <p/>
 * User: Sal Ingrilli
 * Date: May 7, 2012
 * Time: 6:45:30 AM
 */
public class Url {

  // my classes
  private static class Parameter {

    private String name;
    private String value;

    public String getName () { return name; }
    public String value () { return value; }
  }

  // my attributes
  private String protocol;
  private String username;
  private String password;
  private String host;
  private String port;
  private String path;
  private final List<Parameter> parameterList = new LinkedList<Parameter> ();

  // my attributes
  public void setProtocol (final String protocol) { this.protocol = protocol; }
  public String getProtocol () { return protocol; }

  public void setUsername (final String username) { this.username = username; }
  public String getUsername () { return username; }

  public void setPassword (final String password) { this.password = password; }
  public String getPassword () { return password; }

  public void setHost (final String host) { this.host = host; }
  public String getHost () { return host; }

  public void setPort (final String port) { this.port = port; }
  public String getPort () { return port; }

  public void setPath (final String path) { this.path = path; }
  public String getPath () { return path; }

  public List<Parameter> getParameterList () { return parameterList; }

  /**
   * Def ctor to create a Url
   */
  public Url () {

  }

  /**
   * Def ctor to parse a url
   * @param formattedUrl
   */
  public Url (final String formattedUrl) {

    // delegate
    parseUrl (formattedUrl);
  }

  /**
   * Adds the given parameter to this url
   * @param name
   * @param value
   */
  public void addParameter (final String name, final String value) {

    final Parameter parameter = new Parameter ();
    parameter.name = name;
    parameter.value = value;
    parameterList.add (parameter);
  }

  /**
   * Returns the first value for the parameter with the given name
   * @param name
   * @return String
   */
  public String getParameterValueAsString (final String name) {

    for (final Parameter parameter : parameterList) {
      if (parameter.name.equals (name)) {
        return parameter.value;
      }
    }

    // not found
    return null;
  }

  /**
   * Returns the first value for the parameter with the given name
   * @param name
   * @return String
   */
  public Double getParameterValueAsDoubleObject (final String name) {

    // delegate
    final Double defaultValue = null;
    return getParameterValueAsDoubleObject (name, defaultValue);
  }

  /**
   * Returns the first value for the parameter with the given name
   * @param name
   * @return String
   */
  public Double getParameterValueAsDoubleObject (
    final String name,
    final Double defaultValue) {

    final String value = getParameterValueAsString (name);
    return value != null ?
      Double.parseDouble (value) :
      defaultValue;
  }

  /**
   * Returns the first value for the parameter with the given name
   * @param name
   * @return String
   */
  public double getParameterValueAsDouble (
    final String name,
    final double defaultValue) {

    // delegate
    return getParameterValueAsDoubleObject (name, defaultValue);
  }

  /**
   * Returns the first value for the parameter with the given name
   * @param name
   * @return String
   */
  public Integer getParameterValueAsIntObject (final String name) {

    // delegate
    final Integer defaultValue = null;
    return getParameterValueAsIntObject (name, defaultValue);
  }

  /**
   * Returns the first value for the parameter with the given name
   * @param name
   * @return String
   */
  public Integer getParameterValueAsIntObject (
    final String name,
    final Integer defaultValue) {

    final String value = getParameterValueAsString (name);
    return value != null ?
      Integer.parseInt (value) :
      defaultValue;
  }

  /**
   * Returns the first value for the parameter with the given name
   * @param name
   * @return String
   */
  public int getParameterValueAsInt (
    final String name,
    final int defaultValue) {

    // delegate
    return getParameterValueAsIntObject (name, defaultValue);
  }

  /**
   * Looks at the url for parameters with the given name.
   * Any parameters that match the given name, and the parameters that follow it, are tracked in a Map.
   * If the parameter name is encountered again, it and the parameters that follow it, are tracked in a new Map.
   * 
   * This method is useful ONLY when the given parameter name is followed by unique parameters, such as:
   *   "action=doThis&param1=a&param2=b&param3=c", or when there are more section, such as:
   *   "action=doThis&param1=a&param2=b&param3=c&action=doThat&param1=a&param2=b&param3=c&param4=d"
   *    ---------------------------------------- -------------------------------------------------
   * In the above cases, you will get back a List with 2 Maps that look like this:
   *   [action=doThis, param1=a, param2=b, param3=c]
   *   [action=doThat, param1=a, param2=b, param3=c, param4=d]
   * 
   * If you call this method for a url like this:
   *   "action=doThis&param=a&param=b&param=c", you get a Map that looks like that:
   *   [action=doThis, param=c]
   * 
   * @param name
   * @return List<Map<String, String>>
   */
  public List<Map<String, String>> splitParametersToMapByParameterName (final String name) {

    // iterate all parameters
    final List<Map<String, String>> urlParameterMapList = new LinkedList<Map<String, String>> ();
    Map<String, String> parameterMap = null;
    for (final Parameter parameter : parameterList) {

      // when the parameter name matches what you specified, create and track a new map for it
      if (parameter.name.equals (name)) {
        parameterMap = new HashMap<String, String> ();
        urlParameterMapList.add (parameterMap);
      }

      // if we have identified a section of url parameters that starts with the given name
      // track them in the map, including the parameter with the given name
      if (parameterMap != null) {
        parameterMap.put (parameter.name, parameter.value);
      }
    }

    // done
    return urlParameterMapList;
  }

  /**
   * The Object interface
   * Serializes this Url object into a common url
   * @return String
   * @noinspection StringConcatenationInsideStringBufferAppend
   */
  @Override
  public String toString () {

    // protocol://
    final StringBuilder sb = new StringBuilder ();
    if (!StringUtil.isSameAsEmpty (protocol)) {
      sb.append (protocol);
      sb.append ("://");
    }

    // protocol://username:password@
    if (!StringUtil.isSameAsEmpty (username)) {
      sb.append (UrlUtil.encodeText (username));
      if (!StringUtil.isSameAsEmpty (password)) {
        sb.append (":" + UrlUtil.encodeText (password));
      }
      sb.append ("@");
    }

    // protocol://username:password@host
    if (!StringUtil.isSameAsEmpty (host)) {
      sb.append (UrlUtil.encodeText (host));
    }

    // protocol://username:password@host:port
    if (!StringUtil.isSameAsEmpty (port)) {
      sb.append (":");
      sb.append (port);
    }

    // protocol://userName:password@host:port/path1/path2
    // http://sal.ingrilli:shortpasta@syncvoice.com:8080/path1/path2
    if (!StringUtil.isSameAsEmpty (path)) {
      if (!path.startsWith ("/")) {
        sb.append ("/");
      }
      sb.append (path);
    }

    // protocol://userName:password@host:port/path1/path2?param=value1&param=value2
    // http://sal.ingrilli:shortpasta@syncvoice.com:8080/path1/path2?param=value1&param=value2
    boolean addParameterDelimiterFlag = true;
    for (final Parameter parameter : parameterList) {

      // only add the parameterDelimiter once we're adding a parameter
      if (addParameterDelimiterFlag) {
        sb.append ("?");
        addParameterDelimiterFlag = false;
      }
      else {
        sb.append ("&");
      }

      sb.append (UrlUtil.encodeText (parameter.name));
      sb.append ("=");
      if (!StringUtil.isSameAsEmpty (parameter.value)) {
        sb.append (UrlUtil.encodeText (parameter.value));
      }
    }

    // done
    return sb.toString ();
  }

  /**
   * Parses the given formatted url
   * protocol://username:password@host:port/path1/path2?param1=a&param2=b
   *
   * @param formattedUrl
   */
  private void parseUrl (final String formattedUrl) {

    // contains the next url token to parse
    String urlToken = formattedUrl;

    // parse the protocol
    // protocol://username:password@host:port/path1/path2?param1=a&param2=b
    final String protocolSeparator = "://";
    final int protocolSeparatorIndex = urlToken.indexOf (protocolSeparator);
    if (protocolSeparatorIndex >= 0) {
      protocol = urlToken.substring (0, protocolSeparatorIndex);
      urlToken = urlToken.substring (protocolSeparatorIndex + protocolSeparator.length ());
    }

    // parse the params
    // protocol://username:password@host:port/path1/path2?param1=a&param2=b
    {
      final int questionMarkIndex = urlToken.indexOf ('?');
      if (questionMarkIndex >= 0) {

        // parse all parameters
        final String parameters = urlToken.substring (questionMarkIndex + 1);
        final List<String> tokenList = StringUtil.split (parameters, "&");
        for (final String token : tokenList) {

          final int equalIndex = token.indexOf ('=');
          final String name = token.substring (0, equalIndex);
          final String value = token.substring (
            equalIndex + 1,
            token.length ());

          final String decodedName = UrlUtil.decodeText (name);
          final String decodedValue = UrlUtil.decodeText (value);
          addParameter (decodedName, decodedValue);
        }

        // advance to next token
        urlToken = urlToken.substring (0, questionMarkIndex);
      }
    }

    // extract the path string
    // protocol://username:password@host:port/path1/path2?param1=a&param2=b
    {
      final int slashIndex = urlToken.indexOf ('/');
      if (slashIndex > 0) {

        // extract and set the path path
        path = urlToken.substring (slashIndex + 1);

        // advance to next token
        urlToken = urlToken.substring (0, slashIndex);
      }
    }

    // parse the username/password
    // protocol://username:password@host:port/path1/path2?param1=a&param2=b
    {
      final int atIndex = urlToken.indexOf ('@');
      if (atIndex > 0) {

        // extract & set the username and password
        final String userNameAndPassword = urlToken.substring (0, atIndex);
        final int colonIndex = userNameAndPassword.indexOf (':');
        if (colonIndex > 0) {
          username = UrlUtil.decodeText (userNameAndPassword.substring (0, colonIndex));
          password = UrlUtil.decodeText (userNameAndPassword.substring (colonIndex + 1));
        }
        else {
          username = UrlUtil.decodeText (userNameAndPassword);
        }

        // advance to next token
        urlToken = urlToken.substring (atIndex + 1);
      }
    }

    // parse the port
    // protocol://username:password@host:port/path1/path2?param1=a&param2=b
    {
      final int colonIndex = urlToken.indexOf (':');
      if (colonIndex > 0) {

        host = UrlUtil.decodeText (urlToken.substring (0, colonIndex));
        port = UrlUtil.decodeText (urlToken.substring (colonIndex + 1));
      }
      else {

        host = UrlUtil.decodeText (urlToken);
      }
    }
  }
}