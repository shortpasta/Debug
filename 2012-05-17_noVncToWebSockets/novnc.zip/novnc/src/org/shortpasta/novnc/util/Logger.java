package org.shortpasta.novnc.util;

import java.util.Date;
import java.io.StringWriter;
import java.io.PrintWriter;

/**
 * ShortPasta Foundation
 * http://www.shortpasta.org
 * Copyright 2009 and beyond, Sal Ingrilli at the ShortPasta Software Foundation
 * <p/>
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License version 3
 * as published by the Free Software Foundation as long as:
 * 1. You credit the original author somewhere within your product or website
 * 2. The credit is easily reachable and not burried deep
 * 3. Your end-user can easily see it
 * 4. You register your name (optional) and company/group/org name (required)
 * at http://www.shortpasta.org
 * 5. You do all of the above within 4 weeks of integrating this software
 * 6. You contribute feedback, fixes, and requests for features
 * <p/>
 * If/when you derive a commercial gain from using this software
 * please donate at http://www.shortpasta.org
 * <p/>
 * If prefer or require, contact the author specified above to:
 * 1. Release you from the above requirements
 * 2. Acquire a commercial license
 * 3. Purchase a support contract
 * 4. Request a different license
 * 5. Anything else
 * <p/>
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE, similarly
 * to how this is described in the GNU Lesser General Public License.
 * <p/>
 * User: Sal Ingrilli
 * Date: May 6, 2012
 * Time: 11:27:17 PM
 */
public class Logger {

  // my attributes
  private final String objectClassSimpleName;
  boolean debugEnabledFlag = true;
  boolean infoEnabledFlag = true;

  /**
   * Def ctor
   * @param objectClass
   */
  public Logger (final Class objectClass) {

    objectClassSimpleName = objectClass.getSimpleName ();
  }

  /**
   * The Logger interface
   * @return boolean
   */
  public boolean isDebugEnabled () {
    return debugEnabledFlag;
  }

  /**
   * The Logger interface
   * @return boolean
   */
  public boolean isInfoEnabled () {
    return infoEnabledFlag;
  }

  /**
   * Logs the given string as DEBUG
   * @param string
   */
  public void debug (final String string) {

    if (debugEnabledFlag) {
      println (
        "DEBUG",
        string);
    }
  }

  /**
   * Logs the given string as DEBUG
   * @param string
   */
  public void info (final String string) {

    if (infoEnabledFlag) {
      println (
        "INFO",
        string);
    }
  }

  /**
   * Logs the given string as DEBUG
   * @param string
   */
  public void warn (final String string) {

    println (
      "WARN",
      string);
  }

  /**
   * Logs the given string as DEBUG
   * @param string
   */
  public void error (final String string) {

    println (
      "ERROR",
      string);
  }

  /**
   * Logs the given string as DEBUG
   * @param t
   */
  public void error (final Throwable t) {

    error (t.getMessage ());
    error (getStackTraceAsString (t));
  }

  /**
   * Uniformely prints the given log statement
   * @param level
   * @param string
   */
  private void println (
    final String level,
    final String string) {

    System.out.println (
      "<" + level + "> " +
      "<" + new Date () + "> " +
      "<" + objectClassSimpleName + "> " +
      "<" + string + ">");
  }

  /**
   * Returns the exception stack trace as a string
   *
   * @param t
   * @return String
   */
  private static String getStackTraceAsString (final Throwable t) {
    final StringWriter sw = new StringWriter ();
    final PrintWriter pw = new PrintWriter (sw);
    t.printStackTrace (pw);
    return sw.toString ();
  }
}