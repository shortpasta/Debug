package org.shortpasta.novnc.util;

/**
 * ShortPasta Foundation
 * http://www.shortpasta.org
 * Copyright 2009 and beyond, Sal Ingrilli at the ShortPasta Software Foundation
 * <p/>
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License version 3
 * as published by the Free Software Foundation as long as:
 * 1. You credit the original author somewhere within your product or website
 * 2. The credit is easily reachable and not burried deep
 * 3. Your end-user can easily see it
 * 4. You register your name (optional) and company/group/org name (required)
 * at http://www.shortpasta.org
 * 5. You do all of the above within 4 weeks of integrating this software
 * 6. You contribute feedback, fixes, and requests for features
 * <p/>
 * If/when you derive a commercial gain from using this software
 * please donate at http://www.shortpasta.org
 * <p/>
 * If prefer or require, contact the author specified above to:
 * 1. Release you from the above requirements
 * 2. Acquire a commercial license
 * 3. Purchase a support contract
 * 4. Request a different license
 * 5. Anything else
 * <p/>
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE, similarly
 * to how this is described in the GNU Lesser General Public License.
 * <p/>
 * User: Sal Ingrilli
 * Date: May 7, 2012
 * Time: 8:36:28 AM
 * @noinspection ALL
 */
public class Base64Util {
  
  // my interfaces
  private static interface Coder {
    String encode (final byte[] data);
    byte[] decode (final String data);
  }
  
  // my classes
  private static class XmlCoder implements Coder {
    
    public String encode (final byte[] data) {
      return javax.xml.bind.DatatypeConverter.printBase64Binary (data);
    }

    public byte[] decode (final String data) {
      return javax.xml.bind.DatatypeConverter.parseBase64Binary (data);
    }
  }
  
  // my classes
  private static class SunCoder implements Coder {
    
    public String encode (final byte[] data) {
      final sun.misc.BASE64Encoder encoder = new sun.misc.BASE64Encoder ();
      return encoder.encodeBuffer (data);
    }

    public byte[] decode (final String data) {
      try {
        final sun.misc.BASE64Decoder decoder = new sun.misc.BASE64Decoder ();
        return decoder.decodeBuffer (data);
      }
      catch (final java.io.IOException e) {
        throw new RuntimeException (e);
      }
    }
  }
  
  // my classes
  private static class RobertHarderCoder implements Coder {
    
    public String encode (final byte[] data) {
      return org.shortpasta.novnc.thirdparty.robertHarder.Base64.encodeBytes (data);
    }

    public byte[] decode (final String data) {
      try {
        return org.shortpasta.novnc.thirdparty.robertHarder.Base64.decode (data);
      }
      catch (final java.io.IOException e) {
        throw new RuntimeException (e);
      }
    }
  }
  
  // my attributes
  private static final Coder coder = new RobertHarderCoder ();

  /**
   * Decodes the given data
   * @param data
   * @return String
   */
  public static String encode (final byte[] data) {

    // delegate
    return coder.encode (data);
  }

  /**
   * Encodes the given data
   * @param data
   * @return String
   */
  public static byte[] decode (final String data) {

    // delegate
    return coder.decode (data);
  }
}