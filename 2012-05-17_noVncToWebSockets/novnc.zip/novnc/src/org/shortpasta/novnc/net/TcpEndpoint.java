package org.shortpasta.novnc.net;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.LinkedBlockingQueue;
import java.io.InputStream;
import java.io.OutputStream;

import org.shortpasta.novnc.util.AsyncCallback;
import org.shortpasta.novnc.util.Logger;

/**
 * ShortPasta Foundation
 * http://www.shortpasta.org
 * Copyright 2009 and beyond, Sal Ingrilli at the ShortPasta Software Foundation
 * <p/>
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License version 3
 * as published by the Free Software Foundation as long as:
 * 1. You credit the original author somewhere within your product or website
 * 2. The credit is easily reachable and not burried deep
 * 3. Your end-user can easily see it
 * 4. You register your name (optional) and company/group/org name (required)
 * at http://www.shortpasta.org
 * 5. You do all of the above within 4 weeks of integrating this software
 * 6. You contribute feedback, fixes, and requests for features
 * <p/>
 * If/when you derive a commercial gain from using this software
 * please donate at http://www.shortpasta.org
 * <p/>
 * If prefer or require, contact the author specified above to:
 * 1. Release you from the above requirements
 * 2. Acquire a commercial license
 * 3. Purchase a support contract
 * 4. Request a different license
 * 5. Anything else
 * <p/>
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE, similarly
 * to how this is described in the GNU Lesser General Public License.
 * <p/>
 * User: Sal Ingrilli
 * Date: May 10, 2012
 * Time: 11:05:20 PM
 */
public class TcpEndpoint {

  // my attributes
  protected final Logger logger = new Logger (getClass ());
  private InputStream inputStream;
  private OutputStream outputStream;
  private AsyncCallback<byte[]> onReadAsyncCallback;
  private static final AtomicInteger nextInstanceId = new AtomicInteger ();
  private final int instanceId;
  private Thread writeThread;
  private Thread readThread;
  private final LinkedBlockingQueue<byte[]> sendQueue = new LinkedBlockingQueue<byte[]> ();

  public void setInputStream (final InputStream inputStream) { this.inputStream = inputStream; }
  public InputStream getInputStream () { return inputStream; }

  public void setOutputStream (final OutputStream outputStream) { this.outputStream = outputStream; }
  public OutputStream getOutputStream () { return outputStream; }

  public void setOnReadAsyncCallback (final AsyncCallback<byte[]> onReadAsyncCallback) { this.onReadAsyncCallback = onReadAsyncCallback; }
  public AsyncCallback<byte[]> getOnReadAsyncCallback () { return onReadAsyncCallback; }

  /**
   * Def ctor
   */
  public TcpEndpoint () {

    // allocate an instanceId
    instanceId = nextInstanceId.incrementAndGet ();
    logger.debug ("IoProxy (). instanceId: " + instanceId);
  }

  /**
   * Starts this proxy
   */
  public void start () {

    // helpers
    logger.debug ("start ()");

    // create a thread to write data
    {
      final Runnable runnable = new Runnable () {
        public void run () {
          writeRunnable ();
        }
      };

      final String name = "SocketProxy:instanceId=" + instanceId + ",service=write";
      logger.debug ("starting thread: " + name);
      writeThread = new Thread (runnable, name);
      writeThread.setDaemon (true);
      writeThread.start ();
      logger.debug ("started thread: " + writeThread.getName ());
    }

    // create a thread to read data
    {
      final Runnable runnable = new Runnable () {
        public void run () {
          readRunnable ();
        }
      };
      final String name = "SocketProxy:instanceId=" + instanceId + ",service=read";
      logger.debug ("starting thread: " + name);
      readThread = new Thread (runnable, name);
      readThread.setDaemon (true);
      readThread.start ();
      logger.debug ("started thread: " + readThread.getName ());
    }
  }

  /**
   * Stops this client
   */
  public void stop () {

    // delegate
    close ();
  }

  /**
   * Sends the given data
   * @param data
   */
  public void writeAsync (final byte[] data) {

    // enqueue
    sendQueue.offer (data);
  }
  
  /**
   * Sends the given data and waits until it is processed
   * @param data
   */
  public void write (final byte[] data) {

    // delegate
    writeAsync (data);
    
    // and wait for the queue to be empty
    try {
      
      while (!sendQueue.isEmpty ()) {
        Thread.sleep (5);
      }
    }
    catch (final InterruptedException e) {
      
      // propagate
      Thread.currentThread ().interrupt ();
    }
  }

  /**
   * Executes a dedicated thread to connect and send data
   */
  private void writeRunnable () {

    // helpers
    logger.debug ("writeRunnable ()");

    // handle exceptions
    try {

      // forever
      // noinspection InfiniteLoopStatement
      while (true) {

        // wait for the next piece of data
        logger.debug ("writeRunnable (): waiting for data to send");
        final byte[] data = sendQueue.take ();

        // write
        logger.debug ("writeRunnable (): sending data: " + data.length + " bytes");
        outputStream.write (data);
        outputStream.flush ();
      }
    }
    catch (final InterruptedException e) {

      // log
      logger.info ("caught interrupt signal: exiting loop");
    }
    catch (final Exception e) {

      // log
      if (this.outputStream == null) {
        logger.info ("ignoring exception received during outputStream close");
      }
      else {
        logger.error (e);
      }
    }
    finally {

      // nullify reference
      writeThread = null;

      // one side of the channel is bad: close the whole thing
      close ();
    }
  }

  /**
   * Executes a dedicated thread to read data
   */
  private void readRunnable () {

    // helpers
    logger.debug ("readRunnable ()");

    // handle exceptions
    try {

      // forever
      final byte[] byteArray = new byte [1024 * 1024];
      while (true) {

        // read the next chunk of data
        logger.debug ("receiveRunnable (): waiting for data to read");
        final int bytesRead = inputStream.read (byteArray);

        // bytesRead-specific processing
        if (bytesRead > 0) {

          logger.debug ("receiveRunnable (): reading data: " + bytesRead + " bytes");
          final byte[] data = new byte[bytesRead];
          System.arraycopy (byteArray, 0, data, 0, bytesRead);
          onReadAsyncCallback.onSuccess (data);
        }
        else if (bytesRead == -1) {
          logger.debug ("receiveRunnable (): detected EOF via bytesRead = " + bytesRead + ": exiting thread");
          break;
        }
      }
    }
    catch (final Exception e) {

      // log
      if (this.inputStream == null) {
        logger.info ("ignoring exception received during inputStream close");
      }
      else {
        logger.error (e);
      }
    }
    finally {

      // nullify reference
      readThread = null;

      // one side of the channel is bad: close the whole thing
      close ();
    }
  }

  /**
   * Uniformely closes this service
   * You can call close () as many times as you want: only the first invocation is respected
   * This is mostly to make sure that the readyState callbacks occur only once
   */
  private void close () {

    // helpers
    logger.debug ("close ()");

    // interrupt all thread
    {
      final Thread thread = writeThread;
      if (thread != null) {
        logger.debug ("interrupting thread: " + thread.getName ());
        thread.interrupt ();
      }
    }

    {
      final Thread thread = readThread;
      if (thread != null) {
        logger.debug ("interrupting thread: " + thread.getName ());
        thread.interrupt ();
      }
    }
  }
}