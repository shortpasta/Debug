package org.shortpasta.novnc.net;

import java.util.concurrent.atomic.AtomicInteger;
import java.net.Socket;
import java.net.ServerSocket;

import org.shortpasta.novnc.util.AsyncCallback;
import org.shortpasta.novnc.util.Logger;

/**
 * ShortPasta Foundation
 * http://www.shortpasta.org
 * Copyright 2009 and beyond, Sal Ingrilli at the ShortPasta Software Foundation
 * <p/>
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License version 3
 * as published by the Free Software Foundation as long as:
 * 1. You credit the original author somewhere within your product or website
 * 2. The credit is easily reachable and not burried deep
 * 3. Your end-user can easily see it
 * 4. You register your name (optional) and company/group/org name (required)
 * at http://www.shortpasta.org
 * 5. You do all of the above within 4 weeks of integrating this software
 * 6. You contribute feedback, fixes, and requests for features
 * <p/>
 * If/when you derive a commercial gain from using this software
 * please donate at http://www.shortpasta.org
 * <p/>
 * If prefer or require, contact the author specified above to:
 * 1. Release you from the above requirements
 * 2. Acquire a commercial license
 * 3. Purchase a support contract
 * 4. Request a different license
 * 5. Anything else
 * <p/>
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE, similarly
 * to how this is described in the GNU Lesser General Public License.
 * <p/>
 * User: Sal Ingrilli
 * Date: May 10, 2012
 * Time: 10:08:21 PM
 */
public class SocketServer {

  // my attributes
  private final Logger logger = new Logger (getClass ());
  private static final AtomicInteger nextInstanceId = new AtomicInteger ();
  private final int instanceId;
  private ServerSocket serverSocket;
  private Thread runServerLoopThread;
  private AsyncCallback<Socket> onSocketAsyncCallback;
  private int port;

  // my attributes
  public void setOnSocketAsyncCallback (final AsyncCallback<Socket> onSocketAsyncCallback) { this.onSocketAsyncCallback = onSocketAsyncCallback; }
  public AsyncCallback<Socket> getOnSocketAsyncCallback () { return onSocketAsyncCallback; }

  public void setPort (final int port) { this.port = port; }
  public int getPort () { return port; }

  /**
   * Def ctor
   */
  public SocketServer () {

    // allocate an instanceId
    instanceId = nextInstanceId.incrementAndGet ();
    logger.debug ("SocketServer (). instanceId: " + instanceId);
  }

  /**
   * Starts this client
   */
  public void start () {

    // handle exceptions
    try {

      // helpers
      logger.debug ("start ()");

      // open a server socket
      serverSocket = new ServerSocket (port);

      // create a thread to connect and send the data
      {
        final Runnable runnable = new Runnable () {
          public void run () {
            runServerLoop ();
          }
        };

        final String name = "SocketServer:service=runServerLoop,instanceId=" + instanceId;
        logger.debug ("starting thread: " + name);
        runServerLoopThread = new Thread (runnable, name);
        runServerLoopThread.setDaemon (true);
        runServerLoopThread.start ();
      }
    }
    catch (final Exception e) {

      // propagate
      throw new RuntimeException (e);
    }
  }

  /**
   * Stops this client
   */
  public void stop () {

    // delegate
    close ();
  }

  /**
   * Executes a dedicated thread to connect and send data
   */
  private void runServerLoop () {

    // helpers
    logger.debug ("runServerLoop ()");

    // handle exceptions
    try {

      // forever
      // noinspection InfiniteLoopStatement
      while (true) {

        // accept next connection
        final Socket socket = serverSocket.accept ();

        // delegate
        onSocketAsyncCallback.onSuccess (socket);
      }
    }
    catch (final Exception e) {

      // log
      if (this.serverSocket == null) {
        logger.info ("ignoring exception received during socket close");
      }
      else {
        logger.error (e);
      }
    }
    finally {

      // close uniformely
      close ();
    }
  }

  /**
   * Uniformely closes this service
   * You can call close () as many times as you want: only the first invocation is respected
   * This is mostly to make sure that the readyState callbacks occur only once
   */
  private void close () {

    // interrupt all threads
    {
      final Thread thread = runServerLoopThread;
      runServerLoopThread = null;
      if (thread != null) {
        logger.debug ("interrupting thread: " + thread.getName ());
        thread.interrupt ();
      }
    }

    // close the socket
    final ServerSocket serverSocket = this.serverSocket;
    this.serverSocket = null;
    if (serverSocket != null) {

      // handle exceptions
      logger.debug ("closing socket");
      try {

        serverSocket.close ();
      }
      catch (final Exception e) {

        logger.error (e);
      }
    }
  }
}
