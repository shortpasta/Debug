package org.shortpasta.novnc.net;

import java.net.Socket;
import java.net.InetSocketAddress;
import java.io.IOException;

import org.shortpasta.novnc.util.AsyncCallback;
import org.shortpasta.novnc.util.Logger;
import org.shortpasta.novnc.net.SocketServer;
import org.shortpasta.novnc.net.TcpEndpoint;

/**
 * ShortPasta Foundation
 * http://www.shortpasta.org
 * Copyright 2009 and beyond, Sal Ingrilli at the ShortPasta Software Foundation
 * <p/>
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License version 3
 * as published by the Free Software Foundation as long as:
 * 1. You credit the original author somewhere within your product or website
 * 2. The credit is easily reachable and not burried deep
 * 3. Your end-user can easily see it
 * 4. You register your name (optional) and company/group/org name (required)
 * at http://www.shortpasta.org
 * 5. You do all of the above within 4 weeks of integrating this software
 * 6. You contribute feedback, fixes, and requests for features
 * <p/>
 * If/when you derive a commercial gain from using this software
 * please donate at http://www.shortpasta.org
 * <p/>
 * If prefer or require, contact the author specified above to:
 * 1. Release you from the above requirements
 * 2. Acquire a commercial license
 * 3. Purchase a support contract
 * 4. Request a different license
 * 5. Anything else
 * <p/>
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE, similarly
 * to how this is described in the GNU Lesser General Public License.
 * <p/>
 * User: Sal Ingrilli
 * Date: May 10, 2012
 * Time: 10:50:15 PM
 */
public class TcpProxy {

  // my attributes
  private final Logger logger = new Logger (getClass ());
  private SocketServer socketServer;
  private int port;
  private String destinationHost;
  private int destinationPort;

  // my attributes
  public void setPort (final int port) { this.port = port; }
  public int getPort () { return port; }

  public void setDestinationHost (final String destinationHost) { this.destinationHost = destinationHost; }
  public String getDestinationHost () { return destinationHost; }

  public void setDestinationPort (final int destinationPort) { this.destinationPort = destinationPort; }
  public int getDestinationPort () { return destinationPort; }

  /**
   * The Java entry point
   * @param args
   */
  public static void main (final String[] args)
    throws Exception {

    final TcpProxy tcpProxy = new TcpProxy ();
    tcpProxy.setPort (10000);
    tcpProxy.setDestinationHost ("192.168.0.181");
    tcpProxy.setDestinationPort (5900);
    tcpProxy.start ();
    Thread.sleep (120 * 1000);
  }

  /**
   * Starts this TcpProxy
   */
  public void start () {

    // helpers
    logger.debug ("start ()");

    // start a tcpServer on port 10000
    socketServer = new SocketServer ();
    socketServer.setPort (port);
    socketServer.setOnSocketAsyncCallback (new AsyncCallback<Socket> () {
      public void onSuccess (final Socket socket) {
        TcpProxy.this.onSocket (socket);
      }
    });
    socketServer.start ();
  }

  /**
   * Stops this TcpProxy
   */
  public void stop () {

    // helpers
    logger.debug ("stop ()");

    // delegate
    final SocketServer socketServer = this.socketServer;
    this.socketServer = null;
    if (socketServer != null) {
      socketServer.stop ();
    }
  }

  /**
   * Handles a new incoming connection
   * @param sourceSocket
   */
  private void onSocket (final Socket sourceSocket) {

    // handle exceptions
    try {

      // helpers
      logger.debug ("onSocket ()");

      // open a connection to the source 
      final TcpEndpoint sourceTcpEndpoint = new TcpEndpoint ();
      sourceTcpEndpoint.setInputStream (sourceSocket.getInputStream ());
      sourceTcpEndpoint.setOutputStream (sourceSocket.getOutputStream ());

      // open a connection to the target
      final TcpEndpoint destinationTcpEndpoint;
      {
        final InetSocketAddress inetSocketAddress = new InetSocketAddress (destinationHost, destinationPort);
        final Socket destinationSocket = new Socket ();
        destinationSocket.connect (inetSocketAddress);

        destinationTcpEndpoint = new TcpEndpoint ();
        destinationTcpEndpoint.setInputStream (destinationSocket.getInputStream ());
        destinationTcpEndpoint.setOutputStream (destinationSocket.getOutputStream ());
      }

      // link the two
      sourceTcpEndpoint.setOnReadAsyncCallback (new AsyncCallback<byte[]> () {
        public void onSuccess (final byte[] byteArray) {
          destinationTcpEndpoint.writeAsync (byteArray);
        }
      });
      destinationTcpEndpoint.setOnReadAsyncCallback (new AsyncCallback<byte[]> () {
        public void onSuccess (final byte[] byteArray) {
          sourceTcpEndpoint.writeAsync (byteArray);
        }
      });

      // start both
      sourceTcpEndpoint.start ();
      destinationTcpEndpoint.start ();
    }
    catch (final IOException e) {

      // propagate
      throw new RuntimeException (e);
    }
  }
}