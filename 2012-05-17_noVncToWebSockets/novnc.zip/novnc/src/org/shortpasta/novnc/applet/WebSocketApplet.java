package org.shortpasta.novnc.applet;

import java.util.Map;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import org.shortpasta.novnc.exception.AssertRuntimeException;
import org.shortpasta.novnc.util.Logger;

import netscape.javascript.JSObject;

/**
 * ShortPasta Foundation
 * http://www.shortpasta.org
 * Copyright 2009 and beyond, Sal Ingrilli at the ShortPasta Software Foundation
 * <p/>
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License version 3
 * as published by the Free Software Foundation as long as:
 * 1. You credit the original author somewhere within your product or website
 * 2. The credit is easily reachable and not burried deep
 * 3. Your end-user can easily see it
 * 4. You register your name (optional) and company/group/org name (required)
 * at http://www.shortpasta.org
 * 5. You do all of the above within 4 weeks of integrating this software
 * 6. You contribute feedback, fixes, and requests for features
 * <p/>
 * If/when you derive a commercial gain from using this software
 * please donate at http://www.shortpasta.org
 * <p/>
 * If prefer or require, contact the author specified above to:
 * 1. Release you from the above requirements
 * 2. Acquire a commercial license
 * 3. Purchase a support contract
 * 4. Request a different license
 * 5. Anything else
 * <p/>
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE, similarly
 * to how this is described in the GNU Lesser General Public License.
 * <p/>
 * User: Sal Ingrilli
 * Date: Sep 22, 2011
 * Time: 7:36:52 PM
 */
public class WebSocketApplet extends javax.swing.JApplet {

  // my attributes
  protected final Logger logger = new Logger (getClass ());
  private String appletId;
  private String callbackFunctionName;
  private final Map<Integer, WebSocketService> webSocketServiceMap = Collections.synchronizedMap (new HashMap<Integer, WebSocketService> ());
  private int javascriptInvocationId;
  
  // my attributes
  public void setCallbackFunctionName (final String callbackFunctionName) {
    
    logger.debug ("setCallbackFunctionName (): callbackFunctionName: " + callbackFunctionName);
    this.callbackFunctionName = callbackFunctionName;
  }
  
  public boolean getAliveFlag () { return true; }

  /**
   * The Applet interface
   */
  @Override
  public final void init () {

    // propagate
    super.init ();
    
    // acquire the appletId
    appletId = getParameter ("appletId");
    logger.debug ("init(): appletId: " + appletId);
  }

  /**
   * The Applet interface
   */
  @Override
  public void destroy () {
    
    // helpers
    logger.debug ("destroy ()");
    
    // handle exceptions
    try {
      
      // stop all services
      final Set<Integer> webSocketIdSet = new HashSet<Integer> (webSocketServiceMap.keySet ());
      for (final Integer webSocketId : webSocketIdSet) {
        this.close (webSocketId);
      }
    }
    catch (final Exception e) {
      
      // log
      logger.error (e);
    }

    // propagate
    super.destroy ();
  }

  /**
   * Logs the given String and then returns it
   * @param string
   * @return String
   */
  public String test (final String string) {
    
    logger.info ("test (): " + string);
    return string;
  }

  /**
   * Opens a WebSocketService to the given url 
   * @param webSocketId
   * @param url
   * @param connectTimeout
   * @return boolean
   */
  public boolean open (
    final int webSocketId,
    final String url,
    final int connectTimeout) {
    
    // helpers
    logger.debug ("open (): webSocketId: " + webSocketId + ", url: " + url + ", connectTimeout: " + connectTimeout);
    
    // preconditions: the webSocketService cannot already exist
    if (webSocketServiceMap.containsKey (webSocketId)) {
      throw new AssertRuntimeException ("webSocketId already mapped: " + webSocketId);
    }
    
    // objectify, track, and start
    final WebSocketService webSocketService = new WebSocketService ();
    webSocketService.setWebSocketApplet (this);
    webSocketService.setWebSocketId (webSocketId);
    webSocketService.setUrl (url);
    webSocketService.setConnectTimeout (connectTimeout);
    webSocketServiceMap.put (webSocketId, webSocketService);
    webSocketService.start ();
    
    // success
    return true;
  }
  
  /**
   * Sends the given data through the given WebSocketService 
   * @param webSocketId
   * @param data
   */
  public void write (
    final int webSocketId,
    final String data) {
    
    // helpers
    if (logger.isDebugEnabled ()) {
      logger.debug ("send (): webSocketId: " + webSocketId + ", data: " + data.length () + " bytes");
    }
    
    // preconditions: the webSocketService cannot already exist
    final WebSocketService webSocketService = webSocketServiceMap.get (webSocketId);
    if (webSocketService == null) {
      throw new AssertRuntimeException ("webSocketId must be already started: " + webSocketId);
    }
    
    // delegate
    webSocketService.write (data);
  }
  
  /**
   * Closes the given WebSocketService 
   * @param webSocketId
   */
  public void close (
    final int webSocketId) {
    
    // helpers
    logger.debug ("close (): webSocketId: " + webSocketId);
    
    // preconditions: the webSocketService cannot already exist
    final WebSocketService webSocketService = webSocketServiceMap.get (webSocketId);
    if (webSocketService == null) {
      throw new AssertRuntimeException ("webSocketId must be already started: " + webSocketId);
    }
    
    // untrack
    webSocketServiceMap.remove (webSocketId);    
    
    // delegate
    webSocketService.stop ();
  }
  
  /**
   * @param webSocketId
   * @param data
   */
  void callbackDispatchMessageEvent (
    final int webSocketId,
    final String data) {

    invokeCallback (
      webSocketId,
      "dispatchMessageEvent",
      data);
  }

  /**
   * @param webSocketId
   * @param readyState
   */
  void callbackSetReadyStateNoException (
    final int webSocketId,
    final int readyState) {

    // handle exceptions
    try {

      // log
      if (logger.isInfoEnabled ()) {
        logger.debug ("callbackSetReadyState (): webSocketId: " + webSocketId + ", readyState: " + readyState);
      }
      
      invokeCallback (
        webSocketId,
        "setReadyState",
        readyState);
    }
    catch (final Exception e) {
      
      // log
      logger.error (e);
    }
  }

  /**
   * Invokes callbackFunctionName with eval ()
   * @param webSocketId
   * @param messageCode
   * @param data
   * @return Object
   */
  private Object invokeCallback (
    final int webSocketId,
    final String messageCode,
    final Object data) {

    // track
    javascriptInvocationId ++;
    
    // log
    if (logger.isDebugEnabled ()) {
      logger.debug (
        "invokeCallback (), " +
        "callbackFunctionName: " + callbackFunctionName + ", " +
        "appletId: " + appletId + ", " +
        "webSocketId: " + webSocketId + ", " +
        "invocationId: " + javascriptInvocationId + ", " + 
        "messageCode: " + messageCode + ", " +
        "data: " + data);
    }

    /*
    final JSObject jso = JSObject.getWindow (this);
    final String jsCmd = callbackFunctionName + "(" +
      "\"" + appletId + "\", " +
      "\"" + webSocketId + "\", " +
      "\"" + javascriptInvocationId + "\", " +
      "\"" + messageCode + "\", " +
      "\"" + data + "\");";
    return jso.eval (jsCmd);*/
    
    // delegate
    final JSObject jso = JSObject.getWindow (this);
    final Object[] args = new Object[] {
      appletId,
      webSocketId,
      javascriptInvocationId,
      messageCode,
      data
    };
    return jso.call (callbackFunctionName, args);
  }
}