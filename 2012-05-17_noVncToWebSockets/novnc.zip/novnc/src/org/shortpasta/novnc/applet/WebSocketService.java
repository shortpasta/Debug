package org.shortpasta.novnc.applet;

import java.net.Socket;
import java.net.InetSocketAddress;

import org.shortpasta.novnc.util.Url;
import org.shortpasta.novnc.util.Logger;
import org.shortpasta.novnc.util.AsyncCallback;
import org.shortpasta.novnc.util.Base64Util;
import org.shortpasta.novnc.net.TcpEndpoint;

/**
 * ShortPasta Foundation
 * http://www.shortpasta.org
 * Copyright 2009 and beyond, Sal Ingrilli at the ShortPasta Software Foundation
 * <p/>
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License version 3
 * as published by the Free Software Foundation as long as:
 * 1. You credit the original author somewhere within your product or website
 * 2. The credit is easily reachable and not burried deep
 * 3. Your end-user can easily see it
 * 4. You register your name (optional) and company/group/org name (required)
 * at http://www.shortpasta.org
 * 5. You do all of the above within 4 weeks of integrating this software
 * 6. You contribute feedback, fixes, and requests for features
 * <p/>
 * If/when you derive a commercial gain from using this software
 * please donate at http://www.shortpasta.org
 * <p/>
 * If prefer or require, contact the author specified above to:
 * 1. Release you from the above requirements
 * 2. Acquire a commercial license
 * 3. Purchase a support contract
 * 4. Request a different license
 * 5. Anything else
 * <p/>
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE, similarly
 * to how this is described in the GNU Lesser General Public License.
 * <p/>
 * User: Sal Ingrilli
 * Date: Sep 22, 2011
 * Time: 7:45:52 PM
 * @noinspection InfiniteLoopStatement
 */
class WebSocketService {

  // my constants
  private static interface WebSocketReadyState {
    int CONNECTING = 0;
    int OPEN = 1;
    int CLOSING = 2;
    int CLOSED = 3;
  }

  // my attributes
  protected final Logger logger = new Logger (getClass ());
  private WebSocketApplet webSocketApplet;
  private int webSocketId;
  private String url;
  private int connectTimeout;
  private Socket socket;
  private TcpEndpoint tcpEndpoint;

  // my attributes
  public void setWebSocketApplet (final WebSocketApplet webSocketApplet) { this.webSocketApplet = webSocketApplet; }

  public void setWebSocketId (final int webSocketId) { this.webSocketId = webSocketId; }
  public int getWebSocketId () { return webSocketId; }

  public void setUrl (final String url) { this.url = url; }
  public String getUrl () { return url; }

  public void setConnectTimeout (final int connectTimeout) { this.connectTimeout = connectTimeout; }
  public int getConnectTimeout () { return connectTimeout; }

  /**
   * Starts this service
   */
  public void start () {
    
    // helpers
    logger.debug ("start ()");
    
    // connect is a privileged instruction so just execute the whole thing in a prileged block
    final Runnable runnable = AppletInvocationUtil.createPrivilegedRunnable (new Runnable () {
      public void run () {
        startPrivileged ();
      }
    });
    runnable.run ();
    
    // done
    logger.debug ("start (): done");
  }

  /**
   * Starts
   */
  private void startPrivileged () {
    
    
    // handle exceptions
    try {

      // helpers
      logger.debug ("startPrivileged ()");
  
      // extract request parameters via our own url and not java.net.URL otherwise it fails on unknown protocols
      final Url urlObject = new Url (url);
      final String host = urlObject.getHost ();
      final int port = Integer.parseInt (urlObject.getPort ());
      logger.debug ("url: " + url + ", host: " + host + ", port: " + port + ", connectTimeout: " + connectTimeout);
      
      // callback status
      logger.debug ("calling back with WebSocketReadyState.CONNECTING");
      webSocketApplet.callbackSetReadyStateNoException (
        webSocketId,
        WebSocketReadyState.CONNECTING);
  
      // create and track socket so that it can be closed in closeAsync ()
      socket = new Socket ();
  
      // connect inline
      final InetSocketAddress inetSocketAddress = new InetSocketAddress (host, port);
      socket.connect (inetSocketAddress, connectTimeout);
      
      // callback status
      logger.debug ("calling back with WebSocketReadyState.OPEN");
      webSocketApplet.callbackSetReadyStateNoException (
        webSocketId,
        WebSocketReadyState.OPEN);
  
      // create an endpoint to handle the streaming
      logger.debug ("creating TcpEndpoint");
      tcpEndpoint = new TcpEndpoint ();
      tcpEndpoint.setInputStream (socket.getInputStream ());
      tcpEndpoint.setOutputStream (socket.getOutputStream ());
      tcpEndpoint.setOnReadAsyncCallback (new AsyncCallback<byte[]> () {
        public void onSuccess (final byte[] byteArray) {
          
          // encode the data as base64 (the way novnc wants it)
          final String encodedData = Base64Util.encode (byteArray);
          if (logger.isDebugEnabled ()) {
            int sum = 0;
            for (int index = 0; index < byteArray.length; index ++) {
              sum += byteArray [index];
            }
            logger.debug (
              "startPrivileged (): webSocketId: " + webSocketId + ", " +
              "byteArray: " + byteArray.length + " bytes, " +
              "encodedData: " + encodedData.length () + " bytes, sum: " + sum);
            logger.debug ("encodedData: " + encodedData);
          }
          
          // delegate
          WebSocketService.this.webSocketApplet.callbackDispatchMessageEvent (
            webSocketId,
            encodedData);
        }
      });
      
      logger.debug ("starting TcpEndpoint");
      tcpEndpoint.start ();
    }
    catch (final Exception e) {
      
      // log
      logger.error (e);
      
      // callback failure
      logger.debug ("calling back with WebSocketReadyState.CLOSING");
      WebSocketService.this.webSocketApplet.callbackSetReadyStateNoException (
        webSocketId,
        WebSocketReadyState.CLOSING);
      
      // callback failure
      logger.debug ("calling back with WebSocketReadyState.CLOSED");
      WebSocketService.this.webSocketApplet.callbackSetReadyStateNoException (
        webSocketId,
        WebSocketReadyState.CLOSED);
    }
  }

  /**
   * Stops this service
   */
  public void stop () {
    
    // helpers
    logger.debug ("stop ()");
    
    // callback status
    webSocketApplet.callbackSetReadyStateNoException (
      webSocketId,
      WebSocketReadyState.CLOSING);
    
    // delegate
    if (tcpEndpoint != null) {
      logger.debug ("closing tcpEndpoint");
      tcpEndpoint.stop ();
      tcpEndpoint = null;
    }
    
    // handle exceptions
    if (socket != null) {

      logger.debug ("closing socket");
      try {
  
        socket.close ();
      }
      catch (final Exception e) {
  
        logger.error (e);
      }
      socket = null;
    }
    
    // callback status
    webSocketApplet.callbackSetReadyStateNoException (
      webSocketId,
      WebSocketReadyState.CLOSED);
  }

  /**
   * Sends the given data
   * @param data
   */
  public void write (final String data) {
    
    // decode the data because novnc sends it as base64 encoded
    final byte[] decodedData = Base64Util.decode (data);
    logger.debug ("write (): sending data, encoded: " + data.length () + " bytes, decoded: " + decodedData.length + " bytes");
    tcpEndpoint.write (decodedData);
  }
}