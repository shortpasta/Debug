package org.shortpasta.novnc.applet;

import java.security.PrivilegedAction;
import java.security.AccessController;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * ShortPasta Foundation
 * http://www.shortpasta.org
 * Copyright 2009 and beyond, Sal Ingrilli at the ShortPasta Software Foundation
 * <p/>
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License version 3
 * as published by the Free Software Foundation as long as:
 * 1. You credit the original author somewhere within your product or website
 * 2. The credit is easily reachable and not burried deep
 * 3. Your end-user can easily see it
 * 4. You register your name (optional) and company/group/org name (required)
 * at http://www.shortpasta.org
 * 5. You do all of the above within 4 weeks of integrating this software
 * 6. You contribute feedback, fixes, and requests for features
 * <p/>
 * If/when you derive a commercial gain from using this software
 * please donate at http://www.shortpasta.org
 * <p/>
 * If prefer or require, contact the author specified above to:
 * 1. Release you from the above requirements
 * 2. Acquire a commercial license
 * 3. Purchase a support contract
 * 4. Request a different license
 * 5. Anything else
 * <p/>
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE, similarly
 * to how this is described in the GNU Lesser General Public License.
 * <p/>
 * User: Sal Ingrilli
 * Date: May 6, 2012
 * Time: 11:31:50 PM
 */
class AppletInvocationUtil {

  /**
   * My classes
   */
  public static class AppletInvocationHandlerRunnable<RETURN_TYPE> implements Runnable {

    // my attributes
    final AppletInvocationHandler<RETURN_TYPE> appletInvocationHandler;
    RETURN_TYPE returnObject;
    Exception e;

    /**
     * Def ctor
     * @param appletInvocationHandler
     */
    public AppletInvocationHandlerRunnable (final AppletInvocationHandler<RETURN_TYPE> appletInvocationHandler) {
      this.appletInvocationHandler = appletInvocationHandler;
    }

    /**
     * The Runnable interface
     */
    public void run () {

      // delegate
      final PrivilegedAction<Void> privilegedAction = new PrivilegedAction<Void> () {
        public Void run () {

          // handle exceptions
          try {

            // delegate
            returnObject = appletInvocationHandler.run ();
          }
          catch (final Exception e) {

            AppletInvocationHandlerRunnable.this.e = e;
          }

          // done
          return null;
        }
      };

      // execute
      AccessController.doPrivileged (privilegedAction);
    }
  }

  // my variables
  private static final AtomicInteger threadId = new AtomicInteger (0);

  /**
   * Returns a Runnable that executes in privileged mode, and that delegates to the given runnable 
   * @param runnable
   * @return Runnable
   */
  public static Runnable createPrivilegedRunnable (
    final Runnable runnable) {

     // delegate
     final AppletInvocationHandler<Void> appletInvocationHandler = new AppletInvocationHandler<Void> () {
       public Void run () {
         runnable.run ();
         return null;
       }
     };
     return new AppletInvocationHandlerRunnable<Void> (appletInvocationHandler);
  }

  /**
   * Runs this block
   */
  public static <RETURN_TYPE> RETURN_TYPE runAppletInvocationHandler (
    final AppletInvocationHandler<RETURN_TYPE> appletInvocationHandler) {

    // delegate
    final boolean waitForFlag = true;
    return runAppletInvocationHandler (
      appletInvocationHandler,
      waitForFlag);
  }

  /**
   * Runs this block
   */
  public static void runAppletInvocationHandlerAsync (
    final AppletInvocationHandler<?> appletInvocationHandler) {

    // delegate
    final boolean waitForFlag = false;
    runAppletInvocationHandler (
      appletInvocationHandler,
      waitForFlag);
  }

  /**
   * Runs this block
   * @param appletInvocationHandler
   * @param waitForFlag
   * @return RETURN_TYPE
   */
  private static <RETURN_TYPE> RETURN_TYPE runAppletInvocationHandler (
    final AppletInvocationHandler<RETURN_TYPE> appletInvocationHandler,
    final boolean waitForFlag) {

    // handle exceptions
    try {

      // create a Runnable to execute the invocation in a separate thread
      // start the thread as a daemon thread so that it goes away when the applet does...
      final AppletInvocationHandlerRunnable<RETURN_TYPE> runnable = new AppletInvocationHandlerRunnable<RETURN_TYPE> (appletInvocationHandler);
      final String name = "AppletInvocationUtil-" + threadId.incrementAndGet ();
      final Thread thread = new Thread (runnable, name);
      thread.setDaemon (true);
      thread.start ();

      // wait for the thread to finish
      if (waitForFlag) {

        thread.join ();

        // the thread is done, if the operation failed, propagate its exception
        // otherwise return its return object
        if (runnable.e != null) {

          // propagate
          throw new RuntimeException (runnable.e);
        }
        else {

          // done
          return runnable.returnObject;
        }
      }
      else {

        // done: you did not want me to wait for this thread
        return null;
      }
    }
    catch (final InterruptedException e) {

      // propagate
      Thread.currentThread ().interrupt ();
      throw new RuntimeException (e);
    }
  }
}